import React, { Component } from 'react';
import ProductService from "./../../services/service.js";

class ProductUIComponent extends Component {
    constructor(props){
        super(props)
        this.state = {
            ProductID : 0,
            ProductName: "",
            CategoryName: "",
            Manufacturer: "",
            Price: 0,
            Products: [
                {ProductID: 101,
                ProductName: "Laptop",
                CategoryName: "Electronics",
                Manufacturer: "AB Tech",
                Price: 100000},

                {ProductID: 102,
                    ProductName: "Tab",
                    CategoryName: "Electronics",
                    Manufacturer: "AB Tech",
                    Price: 200000}
            ],
            Categories: ["Electronincs","Electricals","Food"],
            Manufacturers: ["AB Tech", "CB Power", "ABC Backer"],
            CriteriaName: "",
            Criteria:["ProductID", "ProductName", "CategoryName", "Manufacturer","Price"],
            Sort: false,
            Reverse: false

        };
        this.serv = new ProductService();
    }
    // e is an event-payload raised on target element
    // we can read the payload data using 'e'
    onChangeProduct(e){
        this.setState({[e.target.name]: e.target.value});
    }    

    onChangeCriteria(e){
        this.setState({CriteriaName: e.target.value});
    }

    onChangeSort(e){
        this.setState({[e.target.name]: e.target.value})
    }

    onChangeReverse(e){
        this.setState({[e.target.name]: e.target.value})
    }

    onClickSort(e){
        let temp = this.state.Products;
        let criteriaType = this.state.CriteriaName;

        temp.sort(function(a,b){
            if(typeof a[criteriaType]== "string"){
                return a[criteriaType].toLowerCase().localeCompare(b[criteriaType].toLowerCase());
            }else{
                return a[criteriaType]-b[criteriaType];
            }
        });
        this.setState({Products: temp})
    }

    onClickReverse(e){
        let temp = this.state.Products;
        let criteriaType = this.state.CriteriaName;

        temp.reverse();
        this.setState({Products: temp})
    }

    OnClickClear(e){
        this.setState({ProductID: 0 });
        this.setState({ProductName: "" });
        this.setState({CategoryName: "" });
        this.setState({Manufacturer: "" });
        this.setState({Price: 0 });
    }

    OnClickSave(e){
        alert(`${this.state.ProductID} 
        ${this.state.ProductName} 
        ${this.state.CategoryName} 
        ${this.state.Manufacturer} 
        ${this.state.Price} `)

        let prd = {
            ProductID: this.state.ProductID,
            ProductName: this.state.ProductName,
            CategoryName: this.state.CategoryName,
            Manufacturer: this.state.Manufacturer,
            Price: this.state.Price
        };
        this.serv
        .postData(prd)
        .then(res => res.json())
        .then(resp => {  //resp.data
            console.log(resp.data);
            
            let tempArray = this.state.Products.slice();
            tempArray.push(resp.data);
            this.setState({Products:tempArray});    
        })
        .catch(error => console.log(error.status));

        // 1. get the copy of the Products array using slice()
        /* let tempArray = this.state.Products.slice();
        // 2. push the new record in to the tempArray
        tempArray.push({
            ProductID: this.state.ProductID,
            ProductName: this.state.ProductName,
            CategoryName: this.state.CategoryName,
            Manufacturer: this.state.Manufacturer,
            Price: this.state.Price
        });
        // 3. 
        this.setState({Products:tempArray}); */
    }

    onClickUpdate(){

        let id = this.state.ProductID;

        let prd = {
            ProductID: this.state.ProductID,
            ProductName: this.state.ProductName,
            CategoryName: this.state.CategoryName,
            Manufacturer: this.state.Manufacturer,
            Price: this.state.Price
        };
        this.serv
        .putData(id,prd)
        .then(res => res.json())
        .then(resp => {  //resp.data
            console.log(resp.data);
            
            let tempArray = this.state.Products.slice();
            tempArray.push(resp.data);
            this.setState({Products:tempArray});    
        })
        .catch(error => console.log(error.status));

    } 
    
    deleteData(row) {
        let prds = 
        this.serv.deteteData(row.ProductID)
        .then((data) => data.json())
        .then((value) => {
           console.log(JSON.stringify(value.data)); 
           
            // let tempArray = this.state.Products.slice();
            // tempArray.pop(resp.data);
            // this.setState({Products:tempArray});  
                                     
        })
        .catch(error => {
            console.log(`Error Occured  ${error.status}`);           
        });
    }

    getselectedProduct(p){
        this.setState({ProductID: p.ProductID });
        this.setState({ProductName: p.ProductName });
        this.setState({CategoryName: p.CategoryName });
        this.setState({Manufacturer: p.Manufacturer });
        this.setState({Price: p.Price });
    }

    //method will be executed immediately after the render() completes its job
    componentDidMount(){
        let prds = this.serv
            .getData()
            .then((data) => data.json())
            .then((value) => {
                this.setState({Products:value.data})
            })
            .catch(error => {
                console.log(`Error Occured  ${error.status}`);           
            });
    }

    render() { 
        return ( 
            <div className="container">
                <div className="form-group">
                    <label htmlFor="ProductID">ProductID</label>
                    <input type="text" className="form-control" 
                    name="ProductID"
                    value={this.state.ProductID} 
                    onChange={this.onChangeProduct.bind(this)} />
                </div>

                <div className="form-group">
                    <label htmlFor="ProductName">ProductName</label>
                    <input type="text" className="form-control"
                    name="ProductName"
                     value={this.state.ProductName}
                     onChange={this.onChangeProduct.bind(this)} />
                </div>

                <div className="form-group">
                    <label htmlFor="CategoryName">CategoryName</label>
                    <select className="form-control" 
                    value={this.state.CategoryName} 
                    name="CategoryName"
                    onChange={this.onChangeProduct.bind(this)}>
                    
                    { this.state.Categories.map((c,i) => (
                            <Options key={i} data ={c} />
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="Manufacturer">Manufacturer</label>
                    <select className="form-control" 
                    value={this.state.Manufacturer} 
                    name="Manufacturer"
                    onChange={this.onChangeProduct.bind(this)}>

                    { this.state.Manufacturers.map((c, i) => (
                            <Options key={i} data ={c} />
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="Price">Price</label>
                    <input type="text" className="form-control" 
                    value={this.state.Price} 
                    name="Price"
                    onChange={this.onChangeProduct.bind(this)}/>
                </div>

                <div className="form-group">
                    <table className="table table-default table-striped">
                        <tbody>
                            <tr>
                                <td>
                                    <input type="button" value="New" className="btn btn-info" 
                                    onClick = {this.OnClickClear.bind(this)}/>
                                </td>
                                <td>
                                    <input type="button" value="Save" className="btn btn-success" 
                                    onClick={this.OnClickSave.bind(this)}/>
                                </td>
                                <td>
                                    <input type="button" value="Update" className="btn btn-warning" 
                                    onClick={this.onClickUpdate.bind(this)}/>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div className="form-group">
                    <table className="table table-default table-striped">
                        <tbody>
                            <tr>
                                <td>
                                <h2><label htmlFor="Criteria">Criteria</label></h2>
                                <select className="form-control" 
                                value={this.state.CriteriaName} 
                                name="Criteria"
                                onChange={this.onChangeCriteria.bind(this)}>

                                { this.state.Criteria.map((c, i) => (
                                    <Options key={i} data ={c} />
                                ))}
                                </select></td>  
                            
                                <td>
                                <div className="radio-inline">
                                        <label className="label label-lg">
                                            <input type="radio" name="radiobtn" 
                                            value="Sort"
                                            onChange={this.onChangeSort.bind(this)}
                                            onClick={this.onClickSort.bind(this)}
                                            /> SORT
                                        </label>
                                    </div>
                                </td>
                           
                                <td>
                                <div className="radio-inline">
                                        <label>
                                            <input type="radio" name="radiobtn" 
                                            value="Reverse"
                                            onChange={this.onChangeReverse.bind(this)}
                                            onClick = {this.onClickReverse.bind(this)}
                                            /> REVERSE
                                        </label>
                                    </div>
                                    </td>                        
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div className="container">
                <table className="table table-default table-striped">
                    <thead className="table-dark">
                        <tr>
                            <th>ProductID</th>
                            <th>ProductName</th>
                            <th>CategoryName</th>
                            <th>Menufacturer</th>
                            <th>Price</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        { this.state.Products.map((prd, idx) => (
                                <TableRow 
                                key={idx} 
                                row={prd} 
                                selected={this.getselectedProduct.bind(this)}
                                deleterow = {this.deleteData.bind(this)}
                                />
                            ))}
                    </tbody>
                </table>
                </div>
            </div>            
         );
    }
}

//Component that will render <option></option>
// props.data is the data passed from the parent of this component
class Options extends Component {
    
    render() { 
        return ( 
            <option value={this.props.data}>{this.props.data}</option>
         );
    }
}

class TableRow extends Component{
    constructor(props){
        super(props);
    }

    onRowClick(){
        //alert(`Row Clicked ${JSON.stringify(this.props.row)}`);
        this.props.selected(this.props.row)
        
    }
    onClickDelete(){
        //alert("Record deleted")
         this.props.deleterow(this.props.row);
    }

    render(){
        return(
            <tr onClick={this.onRowClick.bind(this)}>
                <td>{this.props.row.ProductID}</td>
                <td>{this.props.row.ProductName}</td>
                <td>{this.props.row.CategoryName}</td>
                <td>{this.props.row.Manufacturer}</td>
                <td>{this.props.row.Price}</td>
                <td><input type="button" className="btn btn-danger" value="Delete" 
                onClick={this.onClickDelete.bind(this)} /></td>
            </tr>
        );
    }
}
 
export default ProductUIComponent;